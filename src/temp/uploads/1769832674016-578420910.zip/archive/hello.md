"Succesfully read the docs through api" 
